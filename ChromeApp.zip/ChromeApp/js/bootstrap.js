// Bootstrap app data
window.app = {};